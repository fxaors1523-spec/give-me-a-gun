# Starter: Login + แยกสิทธิ์ + MySQL (Vue 3 / Express)

ชุดเริ่มต้นที่เล็กที่สุดที่ยังได้คะแนนหลัก: Login/Logout ด้วย JWT, แยกสิทธิ์ 3 ระดับ, เชื่อม MySQL จริง

## รัน (โหมดพัฒนา)
```bash
cp .env.example .env            # แล้วเติม DB_PASS, JWT_SECRET, MYSQL_ROOT_PASSWORD
mysql -uroot -p < database/schema.sql      # หรือ docker compose up -d --build
cd backend && npm install && npm start     # http://localhost:3000
cd frontend && npm install && npm run dev  # http://localhost:5173
```
บัญชีเริ่มต้น (รหัสผ่านทุกบัญชี `Pass@1234`): `admin`, `staff01`, `user01`

## ทดสอบ
```bash
cd backend && DB_HOST=127.0.0.1 DB_NAME=app_db DB_USER=app DB_PASS=... npm test
```
`unit.test.js` ไม่ใช้ DB, `api.test.js` ยิง API จริงไปที่ MySQL จริง

## API
| Method | Path | สิทธิ์ | หมายเหตุ |
|---|---|---|---|
| POST | `/api/auth/login` | ทุกคน | Body `{username, password}` → `{token, user}` |
| GET | `/api/auth/me` | login แล้ว | อ่านข้อมูลจาก DB ตาม id ใน Token |
| GET | `/api/users?search=&role=&page=&limit=` | admin, staff | staff เห็นเฉพาะ role=user, admin กรอง role ได้ |
| GET | `/api/users/:id` | login แล้ว | admin ดูได้ทุกคน, คนอื่นดูได้เฉพาะตัวเอง |

Response: `{ "status": "success|error", "message": "...", "data": ... }`
Status: 401 ไม่ได้ login, 403 ไม่มีสิทธิ์, 404 ไม่พบ, 422 ข้อมูลไม่ถูกต้อง, 500 ข้อผิดพลาดภายใน

## เพิ่มฟังก์ชันใหม่ (3 ขั้นตอน)
1. **DB**: เพิ่มตารางใน `database/schema.sql`
2. **Backend**: สร้าง `backend/src/routes/xxx.js` (ลอกรูปแบบจาก `users.js`) แล้วเพิ่ม `app.use('/api/xxx', ...)` ใน `app.js` ใส่ `authenticate(['admin'])` เพื่อกำหนดสิทธิ์
3. **Frontend**: สร้าง `views/XxxView.vue`, เพิ่มบรรทัดใน `router.js` (`meta.roles`) และเมนูใน `App.vue`

## ยังไม่มีในชุดนี้ (ทำต่อเมื่อมีเวลา)
POST/PUT/DELETE และอัปโหลดไฟล์, Swagger, E2E (Playwright), `.gitlab-ci.yml`, Dockerfile ของ Frontend
