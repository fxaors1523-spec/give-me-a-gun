// Integration Test: ยิง API จริงผ่าน Supertest ไปยัง MySQL จริง (ใช้ .env ชุดทดสอบ)
// ต้องมี DB ที่รัน database/schema.sql แล้ว และตั้ง DB_* / JWT_SECRET ใน environment
process.env.JWT_SECRET ||= 'integration-test-secret';
const request = require('supertest');
const app = require('../src/app');
const { pool } = require('../src/db');

afterAll(() => pool.end());

const login = async (username, password = 'Pass@1234') => (await request(app).post('/api/auth/login').send({ username, password })).body;
const bearer = async (username) => ({ Authorization: `Bearer ${(await login(username)).data.token}` });

describe('Login', () => {
  test('สำเร็จ: ได้ token + user และไม่คืน password', async () => {
    const body = await login('admin');
    expect(body.status).toBe('success');
    expect(body.data.token).toBeTruthy();
    expect(body.data.user).toMatchObject({ username: 'admin', role: 'admin' });
    expect(body.data.user.password).toBeUndefined();
  });

  test('รหัสผิด = 401', async () => {
    const res = await request(app).post('/api/auth/login').send({ username: 'admin', password: 'wrong' });
    expect(res.status).toBe(401);
    expect(res.body.status).toBe('error');
  });

  test('ไม่กรอกข้อมูล = 422 พร้อม error รายฟิลด์', async () => {
    const res = await request(app).post('/api/auth/login').send({});
    expect(res.status).toBe(422);
    expect(Object.keys(res.body.data)).toEqual(expect.arrayContaining(['username', 'password']));
  });
});

describe('Authorization', () => {
  test('ไม่มี Token = 401', async () => {
    expect((await request(app).get('/api/users')).status).toBe(401);
  });

  test('user เรียก GET /users = 403', async () => {
    expect((await request(app).get('/api/users').set(await bearer('user01'))).status).toBe(403);
  });

  test('admin เห็นทุก role และกรอง role ได้', async () => {
    const all = await request(app).get('/api/users?limit=50').set(await bearer('admin'));
    expect(all.body.data.items.map((u) => u.role)).toEqual(expect.arrayContaining(['admin', 'staff', 'user']));
    const onlyStaff = await request(app).get('/api/users?role=staff').set(await bearer('admin'));
    expect(onlyStaff.body.data.items.every((u) => u.role === 'staff')).toBe(true);
  });

  test('staff เห็นเฉพาะ role=user แม้ขอ role=admin', async () => {
    const res = await request(app).get('/api/users?role=admin&limit=50').set(await bearer('staff01'));
    expect(res.status).toBe(200);
    expect(res.body.data.items.length).toBeGreaterThan(0);
    expect(res.body.data.items.every((u) => u.role === 'user')).toBe(true);
  });

  test('Pagination + Search ทำงานที่ฝั่ง DB', async () => {
    const page = await request(app).get('/api/users?limit=2&page=2').set(await bearer('admin'));
    expect(page.body.data).toMatchObject({ page: 2 });
    expect(page.body.data.items).toHaveLength(2);
    const found = await request(app).get('/api/users?search=user03').set(await bearer('admin'));
    expect(found.body.data.items.map((u) => u.username)).toEqual(['user03']);
  });

  test('GET /users/:id — ดูของตัวเองได้ ดูของคนอื่น = 403 ไม่พบ = 404 id ผิดรูปแบบ = 422', async () => {
    const user = await bearer('user01');
    const me = (await request(app).get('/api/auth/me').set(user)).body.data;
    expect((await request(app).get(`/api/users/${me.id}`).set(user)).status).toBe(200);
    expect((await request(app).get('/api/users/1').set(user)).status).toBe(403);
    const admin = await bearer('admin');
    expect((await request(app).get('/api/users/99999').set(admin)).status).toBe(404);
    expect((await request(app).get('/api/users/abc').set(admin)).status).toBe(422);
  });
});
