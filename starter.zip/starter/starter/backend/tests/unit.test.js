// Unit Test: ทดสอบ middleware ตรวจสิทธิ์โดยไม่ต้องใช้ DB
process.env.JWT_SECRET = 'unit-test-secret';
const { sign, authenticate } = require('../src/middleware/auth');

const run = (roles, token) => {
  const req = { headers: { authorization: token ? `Bearer ${token}` : '' } };
  let err;
  authenticate(roles)(req, {}, (e) => (err = e));
  return { req, err };
};

test('Token ถูกต้องและ role ตรงสิทธิ์ = ผ่าน', () => {
  const { req, err } = run(['admin'], sign({ id: 1, role: 'admin' }));
  expect(err).toBeUndefined();
  expect(req.auth).toMatchObject({ sub: 1, role: 'admin' });
});

test('role ไม่ตรงสิทธิ์ = 403', () => {
  expect(run(['admin'], sign({ id: 3, role: 'user' })).err.code).toBe(403);
});

test('ไม่มี Token หรือ Token ปลอม = 401', () => {
  expect(run([], '').err.code).toBe(401);
  expect(run([], 'abc.def.ghi').err.code).toBe(401);
});
