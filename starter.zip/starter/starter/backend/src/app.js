const express = require('express');
const cors = require('cors');
const { HttpError } = require('./response');

const app = express();
app.use(cors({ origin: process.env.FRONTEND_URL || true }));
app.use(express.json({ limit: '1mb' }));

app.get('/health', (_req, res) => res.json({ status: 'ok' }));

// เพิ่มฟังก์ชันใหม่: สร้างไฟล์ใน routes/ แล้วเพิ่มบรรทัด app.use ที่นี่
app.use('/api/auth', require('./routes/auth'));
app.use('/api/users', require('./routes/users'));

app.use('/api', (_req, _res, next) => next(new HttpError(404, 'ไม่พบ API ที่เรียกใช้งาน')));

// Error handler กลาง: ทุก error ออกเป็น JSON รูปแบบเดียวกัน
// eslint-disable-next-line no-unused-vars
app.use((err, _req, res, _next) => {
  if (err.type === 'entity.parse.failed') return res.status(400).json({ status: 'error', message: 'รูปแบบ JSON ไม่ถูกต้อง', data: null });
  if (err instanceof HttpError) return res.status(err.code).json({ status: 'error', message: err.message, data: err.data });
  console.error(err);
  res.status(500).json({ status: 'error', message: 'เกิดข้อผิดพลาดภายใน Server', data: null });
});

module.exports = app;
