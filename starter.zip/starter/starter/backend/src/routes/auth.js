const router = require('express').Router();
const bcrypt = require('bcryptjs');
const { body } = require('express-validator');
const { query } = require('../db');
const { sign, authenticate } = require('../middleware/auth');
const validate = require('../middleware/validate');
const { success, HttpError, wrap } = require('../response');

// POST /api/auth/login  Body: { username, password }
router.post(
  '/login',
  body('username').trim().notEmpty().withMessage('ห้ามเว้นว่าง').isLength({ max: 50 }).withMessage('ต้องไม่เกิน 50 ตัวอักษร'),
  body('password').notEmpty().withMessage('ห้ามเว้นว่าง').isLength({ max: 100 }).withMessage('ต้องไม่เกิน 100 ตัวอักษร'),
  validate,
  wrap(async (req, res) => {
    const { username, password } = req.body;
    const [user] = await query('SELECT id, username, password, fullname, role FROM users WHERE username = ?', [username]);
    // ข้อความเดียวกันทั้งกรณีไม่มี user และรหัสผิด (ไม่บอกใบ้ผู้โจมตี)
    if (!user || !(await bcrypt.compare(password, user.password))) throw new HttpError(401, 'Username หรือ Password ไม่ถูกต้อง');
    delete user.password;
    success(res, 'เข้าสู่ระบบสำเร็จ', { token: sign(user), user });
  }),
);

// GET /api/auth/me  (ต้องมี Token) — อ่านข้อมูลผู้ใช้จาก DB ตาม id ใน Token
router.get(
  '/me',
  authenticate(),
  wrap(async (req, res) => {
    const [user] = await query('SELECT id, username, fullname, role FROM users WHERE id = ?', [req.auth.sub]);
    if (!user) throw new HttpError(404, 'ไม่พบบัญชีผู้ใช้');
    success(res, 'ข้อมูลผู้ใช้', user);
  }),
);

module.exports = router;
