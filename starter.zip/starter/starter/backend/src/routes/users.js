const router = require('express').Router();
const { param, query: q } = require('express-validator');
const { query } = require('../db');
const { authenticate } = require('../middleware/auth');
const validate = require('../middleware/validate');
const { success, HttpError, wrap } = require('../response');

const like = (text) => `%${text.replace(/[\\%_]/g, '\\$&')}%`; // escape ตัวอักษรพิเศษของ LIKE

// GET /api/users?search=&role=&page=&limit=  (admin, staff)
// สิทธิ์: admin เห็นทุก role และกรอง role ได้ | staff เห็นเฉพาะ role=user
router.get(
  '/',
  authenticate(['admin', 'staff']),
  q('page').optional({ values: 'falsy' }).isInt({ min: 1 }).withMessage('ต้องเป็นจำนวนเต็มบวก').toInt(),
  q('limit').optional({ values: 'falsy' }).isInt({ min: 1, max: 50 }).withMessage('ต้องเป็นจำนวนเต็ม 1-50').toInt(),
  q('role').optional({ values: 'falsy' }).isIn(['admin', 'staff', 'user']).withMessage('ต้องเป็น admin, staff หรือ user'),
  q('search').optional({ values: 'falsy' }).isLength({ max: 100 }).withMessage('ต้องไม่เกิน 100 ตัวอักษร'),
  validate,
  wrap(async (req, res) => {
    const { page = 1, limit = 5, search = '' } = req.query;
    const role = req.auth.role === 'staff' ? 'user' : req.query.role || '';
    const where = "(username LIKE ? OR fullname LIKE ?) AND (? = '' OR role = ?)";
    const params = [like(search), like(search), role, role];

    const [{ total }] = await query(`SELECT COUNT(*) AS total FROM users WHERE ${where}`, params);
    const items = await query(`SELECT id, username, fullname, role FROM users WHERE ${where} ORDER BY id LIMIT ? OFFSET ?`, [
      ...params,
      limit,
      (page - 1) * limit,
    ]);
    success(res, 'รายการผู้ใช้งาน', { items, total, page, pages: Math.max(1, Math.ceil(total / limit)) });
  }),
);

// GET /api/users/:id  — admin ดูได้ทุกคน, role อื่นดูได้เฉพาะตัวเอง (เทียบกับ id ใน Token ไม่ใช่ค่าจาก Frontend)
router.get(
  '/:id',
  authenticate(),
  param('id').isInt({ min: 1 }).withMessage('ต้องเป็นจำนวนเต็มบวก').toInt(),
  validate,
  wrap(async (req, res) => {
    if (req.auth.role !== 'admin' && req.auth.sub !== req.params.id) throw new HttpError(403, 'คุณไม่มีสิทธิ์ดูข้อมูลผู้ใช้คนนี้');
    const [user] = await query('SELECT id, username, fullname, role FROM users WHERE id = ?', [req.params.id]);
    if (!user) throw new HttpError(404, 'ไม่พบผู้ใช้งาน');
    success(res, 'ข้อมูลผู้ใช้', user);
  }),
);

module.exports = router;
