// รูปแบบ JSON ที่ใช้ทั้งระบบ: { status, message, data }
const success = (res, message, data = null, code = 200) => res.status(code).json({ status: 'success', message, data });

// โยน error พร้อม HTTP code จาก route/middleware ใดก็ได้ ไปให้ error handler ใน app.js
class HttpError extends Error {
  constructor(code, message, data = null) {
    super(message);
    this.code = code;
    this.data = data;
  }
}

// ครอบ async handler ให้ error วิ่งเข้า error handler (ไม่ต้องเขียน try/catch ทุก route)
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

module.exports = { success, HttpError, wrap };
