const jwt = require('jsonwebtoken');
const { HttpError } = require('../response');

// สร้าง JWT: เก็บแค่ id (sub) และ role, หมดอายุตาม .env
const sign = (user) => jwt.sign({ sub: user.id, role: user.role }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '8h' });

// ตรวจ JWT (Authentication) และถ้าระบุ roles ตรวจสิทธิ์ (Authorization)
// ใช้: authenticate() = ต้อง login | authenticate(['admin']) = เฉพาะ admin
const authenticate =
  (roles = []) =>
  (req, _res, next) => {
    const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    try {
      req.auth = jwt.verify(token, process.env.JWT_SECRET);
    } catch {
      return next(new HttpError(401, 'กรุณาเข้าสู่ระบบใหม่'));
    }
    if (roles.length && !roles.includes(req.auth.role)) return next(new HttpError(403, 'คุณไม่มีสิทธิ์ใช้งานส่วนนี้'));
    next();
  };

module.exports = { sign, authenticate };
