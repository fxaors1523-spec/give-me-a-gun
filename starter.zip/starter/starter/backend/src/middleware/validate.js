const { validationResult } = require('express-validator');
const { HttpError } = require('../response');

// วางหลังชุด validator: ถ้ามีข้อมูลไม่ถูกต้อง ตอบ 422 พร้อมข้อความรายฟิลด์
module.exports = (req, _res, next) => {
  const result = validationResult(req);
  if (result.isEmpty()) return next();
  const errors = {};
  for (const e of result.array()) errors[e.path] ??= `${e.path} ${e.msg}`;
  next(new HttpError(422, 'ข้อมูลไม่ถูกต้อง', errors));
};
