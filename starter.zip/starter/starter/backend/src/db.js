// เชื่อมต่อ MySQL (ค่าทั้งหมดมาจาก .env — ไม่มีรหัสผ่านใน source)
const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT) || 3306,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME,
  charset: 'utf8mb4',
  connectionLimit: 10,
});

// รัน SQL แบบใส่พารามิเตอร์ (? แทนค่า) กัน SQL Injection แล้วคืนเฉพาะแถวผลลัพธ์
const query = async (sql, params = []) => (await pool.query(sql, params))[0];

module.exports = { pool, query };
