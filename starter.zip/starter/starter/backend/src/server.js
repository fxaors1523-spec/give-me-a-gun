require('dotenv').config();
// ไม่มี secret สำรองใน source: ถ้าลืมตั้งค่า .env ให้หยุดทันที
if (!process.env.JWT_SECRET) throw new Error('ต้องตั้งค่า JWT_SECRET ใน .env');

const app = require('./app');
const port = Number(process.env.PORT) || 3000;
app.listen(port, () => console.log(`API listening on :${port}`));
