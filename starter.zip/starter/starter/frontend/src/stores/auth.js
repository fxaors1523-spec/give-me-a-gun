import { defineStore } from 'pinia';
import { jwtDecode } from 'jwt-decode';
import { http } from '../lib/api';

// อ่านวันหมดอายุจาก Token ฝั่ง Client เพื่อ UX เท่านั้น — Server ตรวจจริงทุก Request
const notExpired = (token) => {
  try {
    const { exp } = jwtDecode(token);
    return !exp || exp * 1000 > Date.now();
  } catch {
    return false;
  }
};

export const useAuthStore = defineStore('auth', {
  state: () => ({ token: localStorage.getItem('token') || '', user: JSON.parse(localStorage.getItem('user') || 'null') }),
  getters: {
    isLoggedIn: (s) => !!s.token && !!s.user && notExpired(s.token),
    role: (s) => s.user?.role,
  },
  actions: {
    async login(username, password) {
      const { data } = await http.post('/auth/login', { username, password });
      this.token = data.data.token;
      this.user = data.data.user;
      localStorage.setItem('token', this.token);
      localStorage.setItem('user', JSON.stringify(this.user));
    },
    logout() {
      this.token = '';
      this.user = null;
      localStorage.removeItem('token');
      localStorage.removeItem('user');
    },
  },
});
