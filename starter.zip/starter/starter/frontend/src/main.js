import { createApp } from 'vue';
import { createPinia } from 'pinia';
import { createVuetify } from 'vuetify';
import 'vuetify/styles';
import '@mdi/font/css/materialdesignicons.css';

import App from './App.vue';
import router from './router';
import { useAuthStore } from './stores/auth';
import { setupInterceptors } from './lib/api';

const app = createApp(App).use(createPinia()).use(router).use(
  createVuetify({
    theme: { themes: { light: { colors: { primary: '#2563a8' } } } },
    defaults: { VTextField: { variant: 'outlined', density: 'comfortable' }, VSelect: { variant: 'outlined', density: 'comfortable' } },
  }),
);

const auth = useAuthStore();
setupInterceptors(
  () => auth.token,
  () => {
    auth.logout();
    router.push({ name: 'login' });
  },
);

app.mount('#app');
