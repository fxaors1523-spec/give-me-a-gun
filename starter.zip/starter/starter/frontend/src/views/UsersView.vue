<script setup>
import { onMounted, ref, watch } from 'vue';
import { http, errorMessage } from '../lib/api';
import { useAuthStore } from '../stores/auth';

const auth = useAuthStore();
const items = ref([]);
const page = ref(1);
const pages = ref(1);
const total = ref(0);
const search = ref('');
const role = ref('');
const loading = ref(false);
const message = ref('');

// ดึงรายการจาก GET /api/users (ค้นหา + กรอง + แบ่งหน้า ทำที่ DB)
async function load() {
  loading.value = true;
  message.value = '';
  try {
    const params = { page: page.value, limit: 5, search: search.value.trim(), role: role.value };
    const data = (await http.get('/users', { params })).data.data;
    items.value = data.items;
    total.value = data.total;
    pages.value = data.pages;
  } catch (e) {
    message.value = errorMessage(e);
  } finally {
    loading.value = false;
  }
}

const goTo = (n) => {
  page.value = n;
  load();
};

let timer;
watch(search, () => {
  clearTimeout(timer);
  timer = setTimeout(() => goTo(1), 300);
});
watch(role, () => goTo(1));
onMounted(load);
</script>

<template>
  <v-container style="max-width: 900px">
    <v-card rounded="lg" class="pa-4">
      <h1 class="text-h5 mb-4">ผู้ใช้งาน</h1>
      <v-row dense>
        <v-col cols="12" sm="8">
          <v-text-field id="search" v-model="search" placeholder="ค้นหา Username หรือชื่อ..." prepend-inner-icon="mdi-magnify" hide-details clearable />
        </v-col>
        <!-- ตัวกรอง role แสดงเฉพาะ admin (Backend บังคับให้ staff เห็นแค่ user อยู่แล้ว) -->
        <v-col v-if="auth.role === 'admin'" cols="12" sm="4">
          <v-select id="role" v-model="role" :items="[{ title: 'ทุกระดับ', value: '' }, 'admin', 'staff', 'user']" hide-details />
        </v-col>
      </v-row>

      <v-table class="mt-3">
        <thead>
          <tr><th>#</th><th>Username</th><th>ชื่อ-นามสกุล</th><th>ระดับ</th></tr>
        </thead>
        <tbody id="rows">
          <tr v-for="u in items" :key="u.id">
            <td>{{ u.id }}</td>
            <td>{{ u.username }}</td>
            <td>{{ u.fullname }}</td>
            <td><v-chip size="small" :color="u.role === 'admin' ? 'primary' : u.role === 'staff' ? 'info' : undefined">{{ u.role }}</v-chip></td>
          </tr>
          <tr v-if="!items.length && !loading"><td colspan="4" class="text-center">ไม่พบข้อมูล</td></tr>
        </tbody>
      </v-table>

      <div class="d-flex justify-end align-center ga-3 mt-4">
        <v-btn id="prev" variant="outlined" :disabled="page <= 1" @click="goTo(page - 1)">ก่อนหน้า</v-btn>
        <span id="label">หน้า {{ page }} / {{ pages }} (ทั้งหมด {{ total }} รายการ)</span>
        <v-btn id="next" variant="outlined" :disabled="page >= pages" @click="goTo(page + 1)">ถัดไป</v-btn>
      </div>
      <v-alert v-if="message" type="error" variant="tonal" density="compact" class="mt-3" role="alert">{{ message }}</v-alert>
    </v-card>
  </v-container>
</template>
