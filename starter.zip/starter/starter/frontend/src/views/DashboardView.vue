<script setup>
import { onMounted, ref } from 'vue';
import { http, errorMessage } from '../lib/api';

// ข้อความอธิบายสิทธิ์ของแต่ละ role (แสดงให้เห็นว่าแยกระดับผู้ใช้จริง)
const ROLE_INFO = {
  admin: 'ผู้ดูแลระบบ — ดูผู้ใช้ได้ทุกระดับและกรองตามระดับได้',
  staff: 'เจ้าหน้าที่ — ดูรายชื่อผู้ใช้ทั่วไปได้',
  user: 'ผู้ใช้ทั่วไป — ดูข้อมูลของตนเองได้',
};

const me = ref(null);
const message = ref('');

// ดึงข้อมูลจาก DB ผ่าน GET /api/auth/me (ไม่ใช้ค่าที่เก็บไว้ในเบราว์เซอร์)
onMounted(async () => {
  try {
    me.value = (await http.get('/auth/me')).data.data;
  } catch (e) {
    message.value = errorMessage(e);
  }
});
</script>

<template>
  <v-container style="max-width: 720px">
    <v-card rounded="lg" class="pa-4">
      <h1 id="heading" class="text-h5 mb-4">หน้าหลัก</h1>
      <v-alert v-if="message" type="error" variant="tonal" density="compact" role="alert">{{ message }}</v-alert>
      <v-list v-else-if="me" lines="two">
        <v-list-item title="ชื่อ-นามสกุล" :subtitle="me.fullname" prepend-icon="mdi-account" />
        <v-list-item title="Username" :subtitle="me.username" prepend-icon="mdi-at" />
        <v-list-item title="ระดับผู้ใช้" :subtitle="`${me.role} — ${ROLE_INFO[me.role]}`" prepend-icon="mdi-shield-account" />
      </v-list>
      <v-progress-linear v-else indeterminate />
    </v-card>
  </v-container>
</template>
