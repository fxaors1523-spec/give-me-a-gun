<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import { useAuthStore } from '../stores/auth';
import { errorMessage } from '../lib/api';

const auth = useAuthStore();
const router = useRouter();
const username = ref('');
const password = ref('');
const message = ref('');
const loading = ref(false);

async function submit() {
  // ตรวจข้อมูลก่อนส่งไป Backend
  if (!username.value.trim() || !password.value) {
    message.value = 'กรุณากรอก Username และ Password';
    return;
  }
  loading.value = true;
  message.value = '';
  try {
    await auth.login(username.value.trim(), password.value);
    router.push({ name: 'dashboard' });
  } catch (e) {
    message.value = errorMessage(e);
  } finally {
    loading.value = false;
  }
}
</script>

<template>
  <v-container class="d-flex justify-center" style="margin-top: 10vh">
    <v-card width="420" max-width="100%" class="pa-4" rounded="lg">
      <v-card-title class="text-h5 font-weight-bold">เข้าสู่ระบบ</v-card-title>
      <v-card-text>
        <form novalidate @submit.prevent="submit">
          <v-text-field id="username" v-model="username" label="Username" autocomplete="username" />
          <v-text-field id="password" v-model="password" label="Password" type="password" autocomplete="current-password" />
          <v-alert v-if="message" id="message" type="error" variant="tonal" density="compact" class="mb-3" role="alert">{{ message }}</v-alert>
          <v-btn type="submit" color="primary" block size="large" :loading="loading">เข้าสู่ระบบ</v-btn>
        </form>
      </v-card-text>
    </v-card>
  </v-container>
</template>
