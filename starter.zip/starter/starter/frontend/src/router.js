import { createRouter, createWebHistory } from 'vue-router';
import { useAuthStore } from './stores/auth';

// meta.roles = role ที่เข้าหน้านั้นได้ (ไม่ระบุ = ทุกคนที่ login แล้ว)
// เพิ่มหน้าใหม่: เพิ่มอีกหนึ่งบรรทัดที่นี่ + ใส่เมนูใน App.vue
const routes = [
  { path: '/', redirect: '/dashboard' },
  { path: '/login', name: 'login', component: () => import('./views/LoginView.vue'), meta: { guest: true } },
  { path: '/dashboard', name: 'dashboard', component: () => import('./views/DashboardView.vue'), meta: { auth: true } },
  { path: '/users', name: 'users', component: () => import('./views/UsersView.vue'), meta: { auth: true, roles: ['admin', 'staff'] } },
  { path: '/:pathMatch(.*)*', redirect: '/dashboard' },
];

const router = createRouter({ history: createWebHistory(), routes });

// ป้องกันหน้าฝั่ง Client (Backend ตรวจสิทธิ์ซ้ำทุก API อยู่แล้ว)
router.beforeEach((to) => {
  const auth = useAuthStore();
  if (to.meta.auth && !auth.isLoggedIn) return { name: 'login' };
  if (to.meta.guest && auth.isLoggedIn) return { name: 'dashboard' };
  if (to.meta.roles && !to.meta.roles.includes(auth.role)) return { name: 'dashboard' };
});

export default router;
