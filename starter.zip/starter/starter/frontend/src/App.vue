<script setup>
import { useRouter } from 'vue-router';
import { useAuthStore } from './stores/auth';

const auth = useAuthStore();
const router = useRouter();

// เมนูทั้งหมด: roles = role ที่มองเห็นเมนูนี้ (ว่าง = ทุกคน)
const menus = [
  { title: 'หน้าหลัก', to: 'dashboard', icon: 'mdi-view-dashboard' },
  { title: 'ผู้ใช้งาน', to: 'users', icon: 'mdi-account-group', roles: ['admin', 'staff'] },
];
const visible = (m) => !m.roles || m.roles.includes(auth.role);

function logout() {
  auth.logout();
  router.push({ name: 'login' });
}
</script>

<template>
  <v-app>
    <v-app-bar v-if="auth.isLoggedIn" flat border>
      <v-app-bar-title class="font-weight-bold">ระบบจัดการผู้ใช้</v-app-bar-title>
      <template v-for="m in menus" :key="m.to">
        <v-btn v-if="visible(m)" :to="{ name: m.to }" :prepend-icon="m.icon" variant="text">
          <span class="d-none d-sm-inline">{{ m.title }}</span>
        </v-btn>
      </template>
      <v-spacer />
      <span class="text-body-2 mr-3 d-none d-md-inline">{{ auth.user.fullname }} ({{ auth.user.role }})</span>
      <v-btn id="logout" variant="outlined" prepend-icon="mdi-logout" class="mr-2" @click="logout">ออกจากระบบ</v-btn>
    </v-app-bar>
    <v-main class="bg-grey-lighten-4">
      <router-view />
    </v-main>
  </v-app>
</template>
