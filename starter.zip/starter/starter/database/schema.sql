SET NAMES utf8mb4;
CREATE DATABASE IF NOT EXISTS app_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE app_db;

-- ตารางผู้ใช้: username ห้ามซ้ำ, password เก็บเป็น bcrypt hash เท่านั้น
CREATE TABLE IF NOT EXISTS users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    fullname VARCHAR(120) NOT NULL,
    role ENUM('admin', 'staff', 'user') NOT NULL DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_users_role (role)
) ENGINE=InnoDB;

-- บัญชีเริ่มต้น รหัสผ่านทุกบัญชี: Pass@1234
INSERT IGNORE INTO users (username, password, fullname, role) VALUES
('admin',  '$2a$10$mN9du6sLgN41vs4DG7ggAeQ/IYPR6XJIFvZUZuRWJI9BwWwhJfVa6', 'ผู้ดูแลระบบ', 'admin'),
('tech01','$2a$10$mN9du6sLgN41vs4DG7ggAeQ/IYPR6XJIFvZUZuRWJI9BwWwhJfVa6', 'เจ้าหน้าที่ สมชาย', 'staff'),
('user01', '$2a$10$mN9du6sLgN41vs4DG7ggAeQ/IYPR6XJIFvZUZuRWJI9BwWwhJfVa6', 'สมศรี ใจดี', 'user'),
('user02', '$2a$10$mN9du6sLgN41vs4DG7ggAeQ/IYPR6XJIFvZUZuRWJI9BwWwhJfVa6', 'วิชัย มั่นคง', 'user'),
('user03', '$2a$10$mN9du6sLgN41vs4DG7ggAeQ/IYPR6XJIFvZUZuRWJI9BwWwhJfVa6', 'มาลี สุขสันต์', 'user'),
('user04', '$2a$10$mN9du6sLgN41vs4DG7ggAeQ/IYPR6XJIFvZUZuRWJI9BwWwhJfVa6', 'ประสิทธิ์ เรียนดี', 'user'),
('user05', '$2a$10$mN9du6sLgN41vs4DG7ggAeQ/IYPR6XJIFvZUZuRWJI9BwWwhJfVa6', 'นภา แสงทอง', 'user');
